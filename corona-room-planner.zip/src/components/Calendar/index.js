import React, {useEffect, useState} from "react";
import { DatePicker, Divider, Button } from "antd";
import moment from "moment";

function Calendar () {
    const [date, setDate] = useState(moment());
    console.log(date);

    const maxLessons = 10;
    const lessons = Array(maxLessons).fill(0);
    
    const rooms = [
        { 
            id: 1, name: "R213", seats: "40", category: "large",
            bookings: {
                "2021-05-06": [
                    { classId: 1, className: "ITFE", lessonNumber: 1 },
                    { classId: 1, className: "ITFE", lessonNumber: 2 },
                    { classId: 3, className: "ITFO", lessonNumber: 7 },
                    { classId: 3, className: "ITFO", lessonNumber: 8 },
                ],
                "2021-05-20": [
                    { classId: 1, className: "FSIO", lessonNumber: 4 },
                    { classId: 1, className: "FSIO", lessonNumber: 3 },
                    { classId: 3, className: "BLABLA", lessonNumber: 9 },
                    { classId: 3, className: "BLABLA", lessonNumber: 10 },
                ],
            } 
        },

        { 
            id: 1, name: "R212", seats: "40", category: "large",
            bookings: {
                "2021-05-06": [
                    { classId: 1, className: "ITFE", lessonNumber: 1 },
                    { classId: 1, className: "ITFE", lessonNumber: 3 },
                    { classId: 3, className: "ITFO", lessonNumber: 4 },
                    { classId: 3, className: "ITFO", lessonNumber: 7 },
                ],
                "2021-05-20": [
                    { classId: 1, className: "FSIO", lessonNumber: 4 },
                    { classId: 1, className: "FSIO", lessonNumber: 3 },
                    { classId: 3, className: "BLABLA", lessonNumber: 9 },
                    { classId: 3, className: "BLABLA", lessonNumber: 10 },
                ],
            } 
        },

        { 
            id: 1, name: "R211", seats: "40", category: "large",
            bookings: {
                "2021-05-06": [
                    { classId: 1, className: "ITFE", lessonNumber: 1 },
                    { classId: 1, className: "ITFE", lessonNumber: 2 },
                    { classId: 3, className: "ITFO", lessonNumber: 7 },
                    { classId: 3, className: "ITFO", lessonNumber: 8 },
                ],
                "2021-05-20": [
                    { classId: 1, className: "FSIO", lessonNumber: 4 },
                    { classId: 1, className: "FSIO", lessonNumber: 3 },
                    { classId: 3, className: "BLABLA", lessonNumber: 9 },
                    { classId: 3, className: "BLABLA", lessonNumber: 10 },
                ],
            } 
        },
    ]   

    return <React.Fragment> 
        <DatePicker 
            defaultPickerValue={date}
            defaultValue={date}
            onChange={(date, dateString) => {
                setDate(date);                
            }} 
        />
        &nbsp;
        <Button type="primary" onClick={() => {
            window.alert("Ey, du Idi!");
        }}>Raum buchen</Button>
        <Divider />
        <table style={{ width: "100%" }} border={1}>
            <thead>
                <tr>
                    <th>Raumname</th>
                    {
                        lessons.map((item, index) => {
                            return <th style={{ textAlign: "center" }}>{ index + 1 }</th>
                        })
                    }
                </tr>
            </thead>
            <tbody>
                {
                    rooms.map(room => {
                        return <tr>
                            <td>{room.name}</td>
                            {
                                lessons.map((lesson, index) => {
                                    const lessonIndex = index + 1;
                                    const dateString = date.format("YYYY-MM-DD");
                                    if (room.bookings[dateString]) {
                                        const lessonSearch = room.bookings[dateString].find(classItem => classItem.lessonNumber === lessonIndex)
                                        if (!lessonSearch) {
                                            return <td>&nbsp;</td>;
                                        } else {
                                            return <td style={{ backgroundColor: "#c00", textAlign: "center", fontWeight: "bold", color: "white" }}>{lessonSearch.className}</td>;
                                        }
                                    } else {
                                        return <td>&nbsp;</td>;
                                    }
                                })
                            }
                        </tr>
                    })
                }
            </tbody>
        </table>
    </React.Fragment>
}

export default Calendar;